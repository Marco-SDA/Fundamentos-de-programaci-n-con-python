import pygame as pg
import Constantes
import math
import os

class Mazmorra:
    def __init__(self, ancho, alto,):
        self.ancho = ancho
        self.alto = alto
        self.fondo = self.cargar_fondo()
        self.margen_izquierdo = Constantes.margen_i
        self.margen_derecho = Constantes.margen_d
        self.margen_superior = Constantes.margen_s
        self.margen_inferior = Constantes.margen_a
        self.borde_interior = self.crear_borde()
        
        
    def cargar_fondo(self):
        """Carga la imagen de fondo de la mazmorra."""
        ruta = os.path.join("Assets", "Mapa", "Dungeon.png")
        fondo = pg.image.load(ruta).convert_alpha()
        fondo_escalado = pg.transform.smoothscale(fondo, (self.ancho, self.alto))
        return fondo_escalado
    
    def crear_borde(self):
        return pg.Rect(self.margen_izquierdo, self.margen_superior, 
                       self.ancho - (self.margen_izquierdo + self.margen_derecho),   
                       self.alto - (self.margen_superior + self.margen_inferior))
        
        
        
        
    def draw(self, pantalla):
        """Dibuja el fondo en la ventana."""
        pantalla.blit(self.fondo, (0, 0))
        pg.draw.rect(pantalla,(255, 0, 0),self.borde_interior, 2)
    
        