import pygame as pg
import math
import Constantes
from jugador import Mago
from Npc import Enemigo
from Mapa import Mazmorra


pg.init()

pantalla = pg.display.set_mode((Constantes.alto_p, Constantes.ancho_p))
pg.display.set_caption("Caída del Mago")

mapa = Mazmorra(Constantes.alto_p,Constantes.ancho_p )

jugador = Mago(Constantes.ancho_p // 2, Constantes.alto_p//2)
enemigo1 = Enemigo(150, 150, "duende")
enemigos = [Enemigo(150,150,"duende")]
tiempo_respawn = 3
tiempo_muerte_enemigo = 0


ejecutando = True
reloj = pg.time.Clock()
dt = 0

while ejecutando:
    dt = reloj.tick(60) / 1000
    for evento in pg.event.get():
        if evento.type == pg.QUIT:  
            ejecutando = False
    
    tecla = pg.key.get_pressed()
    jugador.movimiento(tecla,mapa)
    enemigo1.mover_hacia_jugador(jugador)
    
    jugador.actualizar_poder([enemigo1])
    jugador.actualizar()
    enemigos = [e for e in enemigos if not e.actualizar_muerte()]
    #jugador.x += jugador.velocidad_x   # Ajusta la velocidad según el tiempo
    #jugador.y += jugador.velocidad_y 
    
    if tecla[pg.K_SPACE]:  # O la tecla que prefieras
        if tecla[pg.K_LEFT] or tecla[pg.K_a]:
            jugador.atacar(-1)  # Izquierda
        elif tecla[pg.K_RIGHT] or tecla[pg.K_d]:
            jugador.atacar(1)  # Derecha
        elif tecla[pg.K_UP] or tecla[pg.K_w]:
            jugador.atacar(2)  # Arriba
        elif tecla[pg.K_DOWN] or tecla[pg.K_s]:
            jugador.atacar(-2)  # Abajo
        else:
            jugador.atacar(1)  # Dirección por defecto (derecha)
    
    jugador.actualizar_invulnerabilidad()
    if jugador.rect.colliderect(enemigo1.rect):
        jugador.recibir_daño(Constantes.Daño_duende)
        overlap_x= min(jugador.rect.right - enemigo1.rect.left,enemigo1.rect.right - jugador.rect.left)
        overlap_y = min(jugador.rect.bottom - enemigo1.rect.top,enemigo1.rect.bottom - jugador.rect.top)
        if abs(overlap_x) < abs(overlap_y):
            enemigo1.x += overlap_x * 0.5
        else:
            enemigo1.y +=  overlap_y * 0.5
        enemigo1.rect.x = enemigo1.x
        enemigo1.rect.y = enemigo1.y
        
    if enemigo1.esta_muerto:
    # Si es la primera vez que muere, guardamos el tiempo actual
        if tiempo_muerte_enemigo == 0:
            tiempo_muerte_enemigo = pg.time.get_ticks()    
        if pg.time.get_ticks() - tiempo_muerte_enemigo > tiempo_respawn * 1000:  # Convertir a milisegundos
            enemigo1 = Enemigo(150, 150, "duende")  # Revive en la posición inicial
            tiempo_muerte_enemigo = 0  # Reiniciamos el contador
    else:
    # Si está vivo, lo movemos
        enemigo1.mover_hacia_jugador(jugador)
        
    
    

    
    mapa.draw(pantalla)
    jugador.draw(pantalla)
    enemigo1.draw(pantalla)
    jugador.draw_poder(pantalla)
    enemigo1.actualizar_invulnerabilidad()
    jugador.draw_barra_vida_j(pantalla)
    enemigo1.draw_barra_vida_e(pantalla)
    
        
    
    
    reloj.tick(60)
    pg.display.flip()
pg.quit()