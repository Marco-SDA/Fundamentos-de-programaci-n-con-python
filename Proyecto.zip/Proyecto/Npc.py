import pygame as pg
import os
import Constantes
import math

class Enemigo:
    def __init__(self, x, y, tipo="duende"):
        self.x = x
        self.y = y
        self.ancho = Constantes.Et1_ancho
        self.alto = Constantes.Et1_alto
        self.tipo = tipo
        #self.rect = pg.Rect(x, y, self.ancho, self.alto)
        self.rect = pg.Rect(x + 10, y + 10, self.ancho - 20, self.alto - 20)
        self.velocidad = 1
        self.rango_deteccion = 300
        self.vida_maxima = Constantes.Et1_vida
        self.vida_actual = self.vida_maxima
        self.invulnerable = False
        self.esta_muerto = False
        self.tiempo_invulnerabilidad = 10  # ms
        self.ultimo_daño = 0
        self.tiempo_muerte = 0
        ruta_muerto = os.path.join("Assets", "Duendes", "Duende_muerto.png")
        self.imagen_muerto = pg.image.load(ruta_muerto).convert_alpha()
        self.imagen_muerto = pg.transform.scale(self.imagen_muerto, (self.ancho, self.alto))
        self.imagen = self.load_image()
        
    def load_image(self):
        ruta_imagen = os.path.join("Assets", "Duendes", "Duende1.png")
        imagen = pg.image.load(ruta_imagen)
        
    
        return pg.transform.scale(imagen, (self.ancho, self.alto))
    def actualizar(self):
        """Actualiza la posición del rectángulo de colisión"""
        self.rect.x = self.x
        self.rect.y = self.y  
          
    def detectar_jugador(self, jugador):    
        distancia = math.sqrt((self.x - jugador.x)**2 + (self.y - jugador.y)**2)
        return distancia <= self.rango_deteccion
    
    def mover_hacia_jugador(self, jugador):
        if self.detectar_jugador(jugador):
            dx = jugador.x - self.x
            dy = jugador.y - self.y
            distancia = max(1, math.sqrt(dx**2 + dy**2))
            distancia_minima = 20
            if distancia > distancia_minima:
                self.x += (dx / distancia) * self.velocidad
                self.y += (dy / distancia) * self.velocidad
            
            self.rect.x = int(self.x)
            self.rect.y = int(self.y)
            
            
    def recibir_daño(self, cantidad):
        tiempo_actual = pg.time.get_ticks()
        if not self.invulnerable or (tiempo_actual - self.ultimo_daño > self.tiempo_invulnerabilidad):
            self.vida_actual = max(0, self.vida_actual - cantidad)
            self.invulnerable = True
            self.ultimo_daño = tiempo_actual
            if self.vida_actual <= 0:
                self.morir()
                
    def actualizar_invulnerabilidad(self):
        tiempo_actual = pg.time.get_ticks()
        if self.invulnerable and (tiempo_actual - self.ultimo_daño > self.tiempo_invulnerabilidad):
            self.invulnerable = False
            
    def draw_barra_vida_e(self, pantalla):
    # Configuración de la barra
        pos_x = self.x + (self.ancho - 40) // 2
        pos_y = self.y - 10  
        ancho_barra = 40
        alto_barra = 5
        vida_porcentaje = self.vida_actual / self.vida_maxima
        ancho_vida = int(ancho_barra * vida_porcentaje)
           
        
        
        pg.draw.rect(pantalla, (255, 0, 0), (pos_x, pos_y, ancho_barra, alto_barra))  # Fondo rojo
        pg.draw.rect(pantalla, (0, 255, 0), (pos_x, pos_y, ancho_vida, alto_barra))  # Vida verde
        pg.draw.rect(pantalla, (255, 255, 255), (pos_x, pos_y, ancho_barra, alto_barra), 1)  #Borde
             
    def morir(self):
        self.esta_muerto = True
        self.vida_actual = 0
        self.velocidad = 0 
        self.tiempo_muerte = pg.time.get_ticks()
        
    def actualizar_muerte(self):
        if self.esta_muerto and pg.time.get_ticks() - self.tiempo_muerte > 3000:  # 3 segundos
            return True  # Indica que debe eliminarse
        return False  
        
    def draw(self, pantalla):
        if self.esta_muerto:
            pantalla.blit(self.imagen_muerto, (self.x, self.y))
        else:
            pantalla.blit(self.imagen, (self.x, self.y))
        