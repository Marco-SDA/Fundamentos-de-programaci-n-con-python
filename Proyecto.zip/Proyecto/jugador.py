import pygame as pg 
import os
import Constantes


class Mago():
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.ancho = Constantes.M_ancho
        self.alto = Constantes.M_alto
        self.aceleracion = Constantes.aceleracion
        self.velocidad_x = 0
        self.velocidad_y = 0
        self.friccion = Constantes.friccion
        self.velocidad_max = Constantes.vel_max
        self.vida_maxima = Constantes.Vida
        self.vida_actual = self.vida_maxima
        self.invulnerable = False
        self.tiempo_invulnerable = Constantes.invulnerable
        self.tiempo_daño = 0
        self.poder_activo = False
        self.poder_imagen = pg.image.load("Assets/Habilidades/Fireball.png").convert_alpha()
        self.poder_imagen = pg.transform.scale(self.poder_imagen, (70,70))
        self.poder_rect = self.poder_imagen.get_rect()
        self.poder_velocidad = 7
        self.alcance_maximo = 400
        self.poder_posicion_inicial = 0
        self.direccion_ataque = 1
        self.poder_rect = pg.Rect(0, 0, 30, 30)
        self.cooldown_ataque = Constantes.habcold 
        self.distancia_recorrida = 0 
        self.ultimo_ataque = 0
        self.esta_muerto = False
        ruta_imagen = os.path.join("Assets", "Idle", "Mago.png")
        self.imagen = pg.image.load(ruta_imagen).convert_alpha()
        ruta_muerto = os.path.join("Assets", "Idle", "Mago_muerto.png")
        self.imagen_muerto = pg.image.load(ruta_muerto).convert_alpha()
        self.imagen = pg.transform.scale(self.imagen, (self.ancho, self.alto))
        self.imagen_muerto = pg.transform.scale(self.imagen_muerto, (self.ancho, self.alto))
        #self.imagen.fill((0, 128, 255))
        ruta_sonido = os.path.join("Assets", "Habilidades", "spell1.mp3")
        self.sonido_ataque = pg.mixer.Sound(ruta_sonido)
        self.sonido_ataque.set_volume(0.1)
        self.rect = pg.Rect(self.x, self.y, self.ancho, self.alto)
        
    #def actualizar(self):
        #self.rect.x = self.x
        #self.rect.y = self.y
        
    def draw(self, pantalla):
        """Dibuja al mago en la ventana."""
        if self.esta_muerto:
            pantalla.blit(self.imagen_muerto, (self.x, self.y))
        else:
            pantalla.blit(self.imagen, (self.x, self.y))
        
    def atacar(self,direccion):
        if self.esta_muerto:  # ← Verifica si está muerto
            return
        tiempo_actual = pg.time.get_ticks()
        if tiempo_actual - self.ultimo_ataque > self.cooldown_ataque:
            self.poder_activo = True
            self.direccion_ataque = direccion
            
            self.sonido_ataque.play()
            
            if direccion == 1:  # Derecha
                self.poder_rect.midleft = (self.rect.right, self.rect.centery)
            elif direccion == -1:  # Izquierda
                self.poder_rect.midright = (self.rect.left, self.rect.centery)
            elif direccion == 2:  # Arriba
                self.poder_rect.midbottom = (self.rect.centerx, self.rect.top)
            elif direccion == -2:  # Abajo
                self.poder_rect.midtop = (self.rect.centerx, self.rect.bottom)
                
            self.distancia_recorrida = 0
            self.ultimo_ataque = tiempo_actual
    
        
    def actualizar_poder(self, enemigos):
        if not self.poder_activo:
            return
        
        
        if self.direccion_ataque == 1:  # Derecha
                self.poder_rect.x += self.poder_velocidad
        elif self.direccion_ataque == -1:  # Izquierda
                self.poder_rect.x -= self.poder_velocidad
        elif self.direccion_ataque == 2:  # Arriba
                self.poder_rect.y -= self.poder_velocidad
        elif self.direccion_ataque == -2:  # Abajo
                self.poder_rect.y += self.poder_velocidad
                
        self.distancia_recorrida += abs(self.poder_velocidad)
        # Verificación de colisión
        for enemigo in enemigos:
            if self.poder_rect.colliderect(enemigo.rect):
                enemigo.recibir_daño(25)
                self.poder_activo = False  # ← Desactiva el poder tras golpear
                return  # Rompe el bucle pero no el método

        # Desactiva el poder si supera el alcance máximo
        self.distancia_recorrida += self.poder_velocidad
        if self.distancia_recorrida > self.alcance_maximo:
                self.poder_activo = False
                
                    
    def draw_poder(self, pantalla):
        if self.poder_activo:
            self.poder_rect.center = (self.poder_rect.x + 15, self.poder_rect.y + 15)
            angulo = 0
            if self.direccion_ataque == -1:  # Izquierda
                angulo = 180
            elif self.direccion_ataque == 2:  # Arriba
                angulo = 90
            elif self.direccion_ataque == -2:  # Abajo
                angulo = 270
            
            
            imagen_rotada = pg.transform.rotate(self.poder_imagen, angulo)
            pantalla.blit(imagen_rotada, self.poder_rect)
            
                
    def recibir_daño(self, cantidad):
        tiempo_actual = pg.time.get_ticks()
        if not self.invulnerable or (tiempo_actual - self.ultimo_daño > self.tiempo_invulnerable):
            self.vida_actual = max(0, self.vida_actual - cantidad)
            self.invulnerable = True
            self.ultimo_daño = tiempo_actual
        if self.vida_actual <= 0:
            self.morir()
            
    def actualizar_invulnerabilidad(self):
        tiempo_actual = pg.time.get_ticks()
        if self.invulnerable and (tiempo_actual - self.ultimo_daño > self.tiempo_invulnerable):
            self.invulnerable = False
            
    def morir(self):
        self.esta_muerto = True
        #print("¡El mago ha muerto!")
        self.velocidad_max = 0# Aquí iría el respawn o game over
        pg.time.set_timer(pg.USEREVENT + 1, 3000)   
    
    def draw_barra_vida_j(self, pantalla):
        ancho_barra = 200  # Ancho total de la barra
        alto_barra = 20
        vida_porcentaje = self.vida_actual / self.vida_maxima
        ancho_vida = ancho_barra * vida_porcentaje
        pg.draw.rect(pantalla, (255, 0, 0), (10, 10, ancho_barra, alto_barra))
        pg.draw.rect(pantalla, (0, 255, 0), (10, 10, ancho_vida, alto_barra))
                               
    def actualizar(self):
        self.rect = pg.Rect(self.x, self.y, self.ancho, self.alto)
    
            
    def movimiento(self, tecla, mapa):
        
        aceleracion_x = 0
        aceleracion_y = 0
        
        if tecla[pg.K_a] or tecla[pg.K_LEFT]:    # Izquierda
            self.velocidad_x -= self.aceleracion
        if tecla[pg.K_d] or tecla[pg.K_RIGHT]:   # Derecha
            self.velocidad_x += self.aceleracion
        if tecla[pg.K_w] or tecla[pg.K_UP]:      # Arriba
            self.velocidad_y -= self.aceleracion
        if tecla[pg.K_s] or tecla[pg.K_DOWN]:    # Abajo
            self.velocidad_y += self.aceleracion
            
        
            
        if aceleracion_x != 0 and aceleracion_y != 0:
            aceleracion_x *= 0.7071  # 1/√2
            aceleracion_y *= 0.7071
            
        self.velocidad_x += aceleracion_x
        self.velocidad_y += aceleracion_y
        
        
        self.velocidad_x *= self.friccion
        self.velocidad_y *= self.friccion
        self.velocidad_x = max(-self.velocidad_max, min(self.velocidad_x, self.velocidad_max))
        self.velocidad_y = max(-self.velocidad_max, min(self.velocidad_y, self.velocidad_max))
        
        nueva_x = self.x + self.velocidad_x
        nueva_y = self.y + self.velocidad_y
        
        mago_rect = pg.Rect(nueva_x, nueva_y, self.ancho, self.alto)
        
        if mapa.borde_interior.contains(mago_rect):
        # Si no hay colisión, actualiza la posición real
            self.x = nueva_x
            self.y = nueva_y
        else:
        # Si hay colisión, ajusta la posición para que no salga
            if nueva_x < mapa.borde_interior.left:
                self.x = mapa.borde_interior.left
            elif nueva_x + self.ancho > mapa.borde_interior.right:
                self.x = mapa.borde_interior.right - self.ancho
            if nueva_y < mapa.borde_interior.top:
                self.y = mapa.borde_interior.top
            elif nueva_y + self.alto > mapa.borde_interior.bottom:
                self.y = mapa.borde_interior.bottom - self.alto
        
           
        self.actualizar()