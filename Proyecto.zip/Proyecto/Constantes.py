alto_p = 800
ancho_p = 600

margen_i = 110
margen_d = 110
margen_s = 85
margen_a = 85

Vida = 100
habcold = 1500

M_alto = 55
M_ancho = 50

Et1_alto = 49
Et1_ancho = 40
Et1_vida = 60

aceleracion = 0.8
friccion = 0.8
vel_max = 8


Daño_duende = 10
invulnerable = 400

NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)